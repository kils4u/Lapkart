package paytm_java;
public class PaytmConstants {
  public final static String MID="WorldP64425807474247";
  public final static String MERCHANT_KEY="kbzk1DSbJiV_O3p5";
  public final static String INDUSTRY_TYPE_ID="Retail";
  public final static String CHANNEL_ID="WEB";
  public final static String WEBSITE="worldpressplg";
  public final static String PAYTM_URL="https://securegw-stage.paytm.in/theia/processTransaction"; 
  
}
